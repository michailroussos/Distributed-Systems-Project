public class ShowResults {

    void getResults(){


    }


    void showResults(){


    }


}
