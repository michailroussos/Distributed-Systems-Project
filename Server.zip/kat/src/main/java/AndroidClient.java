/*public class AndroidClient {

    void initializeAndroidClient(){

    }


} */
