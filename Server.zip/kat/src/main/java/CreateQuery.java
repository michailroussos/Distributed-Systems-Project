public class CreateQuery {

    void getLocation(){

    }

    void createQuery(){

    }

    void sendQueryToServer(){

    }

}
