package kat.recsystem;

public class CreateQueryImpl implements CreateQuery {

    @Override
    public void sendQueryToServer(int id, double latitude, double longitude, int k, String cat) {


    }
}
